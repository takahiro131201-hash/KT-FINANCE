K.T FINANCE v6.4 FIRE
GitHub Pages: index.html をリポジトリのルートに配置してください。
旧バックアップの復元は設定タブから行い、復元前に現在データのバックアップを取ってください。
HTTPS環境で暗号化APIが利用可能です。
manifest.webmanifest / sw.js / icon は元ファイルに含まれていません。PWAインストール・オフライン動作には別途用意が必要です。
